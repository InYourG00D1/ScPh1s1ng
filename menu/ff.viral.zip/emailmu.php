<?php
$emailku = 'Emailmu@gmail.com';
?>