<?php
$ripalsendemail = 'Uhhuinfo.com-ganti-emailmu@gmail.com';
?>