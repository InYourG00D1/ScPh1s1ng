<!-- DETOL SHOP -->
<?php
$emailku = 'fajarikeh01@gmail.com';
?>