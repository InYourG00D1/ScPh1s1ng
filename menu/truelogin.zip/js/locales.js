LOCALE_LIST = [
	{'region': 'US', 'code': 'en', 'lname': 'International - English'},
	{'region': 'SG', 'code': 'en', 'lname': 'Singapore - English'},
	{'region': 'SG', 'code': 'zh', 'lname': 'æ–°åŠ å¡ - ç®€ä½“ä¸­æ–‡'},
	{'region': 'TW', 'code': 'zh-TW', 'lname': 'å°ç£ - ç¹ä½“ä¸­æ–‡'},
	{'region': 'PH', 'code': 'en', 'lname': 'Philippines - English'},
	{'region': 'TH', 'code': 'th', 'lname': 'à¹„à¸—à¸¢ - à¹„à¸—à¸¢'},
	{'region': 'ID', 'code': 'id', 'lname': 'Indonesia - Bahasa Indonesia'},
	{'region': 'VN', 'code': 'vi', 'lname': 'Viá»‡t Nam - TiÃªÌng viá»‡t'},
	{'region': 'RU', 'code': 'ru', 'lname': 'Ð Ð¾ÑÑÐ¸Ñ - Ð ÑƒÑÑÐºÐ¸Ð¹'},
	{'region': 'MY', 'code': 'en', 'lname': 'Malaysia - English'}
];